"""Test Package for guessing game.

Author: Zak Oster zcoster@ksu.edu
Version: 0.1
"""
